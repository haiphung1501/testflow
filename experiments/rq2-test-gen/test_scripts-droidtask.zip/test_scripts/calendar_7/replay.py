
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Add all the contacts anniversaries into Calendar
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")

# Expected behaviour: Touching the button with content description "New Event" navigated from the main screen to a new event creation screen. This screen includes various fields and options for entering event details, such as title, location, description, date, time, reminders, and event color. (page changed from Main to Event)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Title' and @resource-id='com.simplemobiletools.calendar.pro:id/event_title']").send_keys("John's Anniversary")
    print("Fill a focused textfield that has text 'Title' with 'John's Anniversary': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Title' with 'John's Anniversary': FAILED")

# Expected behaviour: The textfield previously labeled "Title" has been updated to "John's Anniversary."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='September 10 (Tue)' and @resource-id='com.simplemobiletools.calendar.pro:id/event_start_date']").click()
    print("Touch on a button that has text 'September 10 (Tue)': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'September 10 (Tue)': FAILED")

# Expected behaviour: The screen changed from an event details screen to a date picker screen where the user can select a specific date.


try:
    driver.find_element(AppiumBy.XPATH, "//android.view.View[@text='11' and @content-desc='11 September 2024']").click()
    print("Touch on a button that has text '11': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text '11': FAILED")

# Expected behaviour: The date has changed from "Tue, Sep 10" to "Wed, Sep 11," and the button with the text "11" is now selected, while the button with the text "10" is no longer selected.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")

# Expected behaviour: Tapping the "OK" button transitioned the screen from a calendar date selection view to an event creation view. The new screen includes fields for event details such as the event name, location, description, and time, along with options to set reminders and repetition.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Save' and @resource-id='com.simplemobiletools.calendar.pro:id/save']").click()
    print("Touch on a button that has content_desc 'Save': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Save': FAILED")

# Expected behaviour: Touching the "Save" button transitioned the screen from an event creation form to a main calendar view. (page changed from Event to Main)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")

# Expected behaviour: A new overlay appeared with additional buttons, including one labeled "Task" and another labeled "Event."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Event' and @resource-id='com.simplemobiletools.calendar.pro:id/fab_event_label']").click()
    print("Touch on a button that has text 'Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Event': FAILED")

# Expected behaviour: After touching the button labeled "Event" on the main screen, the user is navigated to a new screen that allows the creation of a new event. This new screen includes fields and options such as "Title," "Location," "Description," and various date and time settings related to the event. (page changed from Main to Event)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='September 10 (Tue)' and @resource-id='com.simplemobiletools.calendar.pro:id/event_start_date']").click()
    print("Touch on a button that has text 'September 10 (Tue)': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'September 10 (Tue)': FAILED")

# Expected behaviour: Touching the button with the text "September 10 (Tue)" opened a date picker, displaying a calendar for the year 2024 with September 10 selected, along with navigation buttons for previous and next month, and options to cancel or confirm the date selection.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")

# Expected behaviour: Touching the "OK" button transitioned the screen from a calendar date selection interface to an event creation interface, where the user can input details such as the event title, location, description, and set reminders.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Title' and @resource-id='com.simplemobiletools.calendar.pro:id/event_title']").send_keys("Sarah's Anniversary")
    print("Fill a textfield that has text 'Title' with 'Sarah's Anniversary': SUCCESS")
    wait()
except Exception as e:
    print("Fill a textfield that has text 'Title' with 'Sarah's Anniversary': FAILED")

# Expected behaviour: The textfield that previously had the text "Title" is now filled and focused with the text "Sarah's Anniversary".


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='September 10 (Tue)' and @resource-id='com.simplemobiletools.calendar.pro:id/event_start_date']").click()
    print("Touch on a button that has text 'September 10 (Tue)': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'September 10 (Tue)': FAILED")

# Expected behaviour: The user touched a button labeled "September 10 (Tue)," which opened a date picker interface. The new screen displays buttons for selecting the date, including buttons for days of the month, navigation buttons for previous and next months, and action buttons labeled "Cancel" and "OK."


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
