
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.contacts.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.contacts.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.contacts.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.contacts.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.contacts.pro',
        'com.simplemobiletools.contacts.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Send a text message to Bob with the following content:'Goodmorning'
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.view.ViewGroup[@resource-id='com.simplemobiletools.contacts.pro:id/item_contact_frame']").click()
    print("Touch on a button that has text 'Bob': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Bob': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='Send SMS' and @resource-id='com.simplemobiletools.contacts.pro:id/contact_send_sms']").click()
    print("Touch on a button that has content_desc 'Send SMS': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Send SMS': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Type a message' and @resource-id='com.simplemobiletools.smsmessenger:id/thread_type_message']").send_keys("Goodmorning")
    print("Fill a textfield that has text 'Type a message' with 'Goodmorning': SUCCESS")
    wait()
except Exception as e:
    print("Fill a textfield that has text 'Type a message' with 'Goodmorning': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='SMS' and @content-desc='OK' and @resource-id='com.simplemobiletools.smsmessenger:id/thread_send_message']").click()
    print("Touch on a button that has text 'SMS': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'SMS': FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
