
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Search for the song "test1" and play it
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='Search' and @resource-id='com.simplemobiletools.musicplayer:id/top_toolbar_search_icon']").click()
    print("Touch on a button that has content_desc 'Search': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Search': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Search' and @resource-id='com.simplemobiletools.musicplayer:id/top_toolbar_search']").send_keys("test1")
    print("Fill a focused textfield that has text 'Search' with 'test1': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Search' with 'test1': FAILED")
try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
