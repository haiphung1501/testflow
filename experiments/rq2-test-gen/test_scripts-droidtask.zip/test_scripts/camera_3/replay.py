
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.camera" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.camera" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.camera":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.camera is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.camera',
        'com.simplemobiletools.camera.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Rotate right the last picture I took and save it as pic4.jpg
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='View last captured media' and @resource-id='com.simplemobiletools.camera:id/last_photo_video_preview']").click()
    print("Touch on a button that has content_desc 'View last captured media': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'View last captured media': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Rotate right']").click()
    print("Touch on a button that has text 'Rotate right': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Rotate right': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")
try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
