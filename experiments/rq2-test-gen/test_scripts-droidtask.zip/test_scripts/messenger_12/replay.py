
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.smsmessenger" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.smsmessenger" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.smsmessenger":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.smsmessenger is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.smsmessenger',
        'com.simplemobiletools.smsmessenger.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Delete and Bob's message records
"""

try:
    elem = driver.find_element(AppiumBy.XPATH, "//android.widget.FrameLayout[@resource-id='com.simplemobiletools.smsmessenger:id/conversation_frame']")
    action = TouchAction(driver)
    action.long_press(elem).perform()
    print("Long touch on a button that has text 'Bob, Hi, 10:29 PM': SUCCESS")
    wait()
except Exception as e:
    print("Long touch on a button that has text 'Bob, Hi, 10:29 PM': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Delete' and @resource-id='com.simplemobiletools.smsmessenger:id/cab_delete']").click()
    print("Touch on a button that has content_desc 'Delete': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Delete': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='Yes' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'Yes': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Yes': FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
