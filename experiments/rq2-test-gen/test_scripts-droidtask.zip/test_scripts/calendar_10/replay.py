
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Change the event reminder sound of Calendar app to adara
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Settings' and @resource-id='com.simplemobiletools.calendar.pro:id/settings']").click()
    print("Touch on a button that has content_desc 'Settings': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Settings': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.calendar.pro:id/settings_customize_notifications_holder']").click()
    print("Touch on a button that has text 'Customize notifications': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Customize notifications': FAILED")

# Expected behaviour: Touching the "Customize notifications" button navigated from the main settings screen to a detailed app notification settings screen, where various notification options such as "All Calendar notifications" and "Allow notification dot" are now visible. (page changed from Main to Settings)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Regular event, ~1 notification per week': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Regular event, ~1 notification per week': FAILED")

# Expected behaviour: The action of touching the button labeled "Regular event, ~1 notification per week" navigated the user to a new screen titled "Notification category" where detailed settings for the "Regular event" notifications are displayed, including options for notification behavior such as "Default," "May ring or vibrate based on phone settings," "Silent," and additional settings like "Pop on screen" and "Sound, Vibration, Show notification dot, Override Do Not Disturb." (page changed from Main to Settings)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Advanced, Sound, Vibration, Show notification dot, Override [...]': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Advanced, Sound, Vibration, Show notification dot, Override [...]': FAILED")

# Expected behaviour: The button labeled "Advanced, Sound, Vibration, Show notification dot, Override" was touched, leading to the expansion of detailed notification settings. These settings now include individual options for Sound, Vibration, and other notification behaviors. (page changed from Main to Settings)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Sound, Default notification sound': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Sound, Default notification sound': FAILED")

# Expected behaviour: Touching the button labeled "Sound, Default notification sound" opened a new screen that allows the user to pick a notification sound. The new screen lists various sound options, such as "None," "Adara," "Altair," "Alya," and many others, along with buttons to confirm or cancel the selection. (page changed from Main to Settings)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.CheckedTextView[@text='Adara' and @resource-id='com.android.soundpicker:id/checked_text_view']").click()
    print("Touch on a button that has text 'Adara': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Adara': FAILED")

# Expected behaviour: The button with the text "Adara" has been selected, and it is now a checked button, while the previously checked button "Default notification sound" is now an unchecked button. (page changed from Main to Settings)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")
try:
    driver.back()
    print("Press the back button 2 times because you stayed on the pages not belonging to the target app for too long: SUCCESS")
    wait()
except Exception as e:
    print("Press the back button 2 times because you stayed on the pages not belonging to the target app for too long: FAILED")

# Expected behaviour: Touching the "OK" button on the RingtonePicker screen navigated the user to the Settings screen, which includes various settings options like color customization, general settings, and reminders.


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
