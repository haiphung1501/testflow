
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.notes.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.notes.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.notes.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.notes.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.notes.pro',
        'com.simplemobiletools.notes.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Go to setting  change app theme to light
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Settings']").click()
    print("Touch on a button that has text 'Settings': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Settings': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'COLOR CUSTOMIZATION, Customize colors, Customize widget colors[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'COLOR CUSTOMIZATION, Customize colors, Customize widget colors[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text 'STARTUP, Place cursor to the end of note, Show keyboard on startup[...and more]': FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
