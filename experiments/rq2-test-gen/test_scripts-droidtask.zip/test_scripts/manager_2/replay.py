
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.filemanager.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.filemanager.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.filemanager.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.filemanager.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.filemanager.pro',
        'com.simplemobiletools.filemanager.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Change the theme to light
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Settings' and @resource-id='com.simplemobiletools.filemanager.pro:id/settings']").click()
    print("Touch on a button that has content_desc 'Settings': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Settings': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.view.ViewGroup[@resource-id='com.simplemobiletools.filemanager.pro:id/settings_color_customization_holder']").click()
    print("Touch on a button that has text 'Customize colors': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Customize colors': FAILED")

# Expected behaviour: Touching the "Customize colors" button navigated from the "Settings" screen to the "Customization" screen, where options for customizing the theme and colors of the app are now available. (page changed from Settings to Customization)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/customization_theme_holder']").click()
    print("Touch on a button that has text 'Theme, Dark': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Theme, Dark': FAILED")

# Expected behaviour: After touching the button that has the text "Theme, Dark," a warning message is displayed, and a new button with the text "OK" appears on the screen.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")

# Expected behaviour: Touching the "OK" button removed the warning text and the "OK" button itself, and it revealed several new buttons related to theme customization options such as "Auto light / dark," "Light," "Dark," "Dark red," "White," "Black & White," and "Custom."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RadioButton[@text='Light']").click()
    print("Touch on a button that has text 'Light': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Light': FAILED")

# Expected behaviour: Touching the "Light" button opened a customization screen where you can adjust various color settings for the theme, including text color, background color, primary color, and app icon color.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Save' and @resource-id='com.simplemobiletools.filemanager.pro:id/save']").click()
    print("Touch on a button that has content_desc 'Save': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Save': FAILED")

# Expected behaviour: Touching the "Save" button on the Customization screen navigated the user to the Settings screen, which includes various configuration options like color customization, managing favorites, and changing date and time formats. (page changed from Customization to Settings)


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
