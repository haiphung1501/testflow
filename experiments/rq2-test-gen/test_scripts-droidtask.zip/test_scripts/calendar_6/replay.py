
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Create an event of 'homework' with daily repetition and save it
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")
try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")

# Expected behaviour: Pressing the "BACK" button navigated from a screen with various calendar-related action buttons ("Go to date," "Print," "Add holidays," etc.) to a screen displaying a yearly calendar view with buttons for navigating months and settings, as well as a search functionality.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Change view' and @resource-id='com.simplemobiletools.calendar.pro:id/change_view']").click()
    print("Touch on a button that has content_desc 'Change view': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Change view': FAILED")

# Expected behaviour: Touching the button with content description "Change view" opened a menu with buttons for selecting different calendar views, including "Daily view," "Weekly view," "Monthly view," "Monthly and daily view," "Yearly view" (checked), and "Simple event list."


try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")

# Expected behaviour: Pressing the "BACK" button navigated from a screen with various view buttons (Daily, Weekly, Monthly, etc.) to a calendar overview screen featuring search functionality, navigation buttons for changing views, and a detailed month-by-month layout for the year 2024.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")

# Expected behaviour: Touching the "More options" button has revealed additional buttons with various functionalities, including "Go to date," "Print," "Add holidays," "Add contact birthdays," "Add contact anniversaries," and "About."


try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")

# Expected behaviour: Pressing the "BACK" button navigated from a screen with various action buttons related to dates, holidays, contacts, and app information to a calendar view screen that displays a search bar, navigation arrows, and month buttons for each month of the year 2024.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='Search' and @resource-id='com.simplemobiletools.calendar.pro:id/top_toolbar_search_icon']").click()
    print("Touch on a button that has content_desc 'Search': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Search': FAILED")

# Expected behaviour: The "Search" button has been replaced by a "Back" button, and the textfield with the text "Search" is now focused.


try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")

# Expected behaviour: Touching the "More options" button revealed additional buttons with the options "Go to date," "Print," "Add holidays," "Add contact birthdays," "Add contact anniversaries," and "About."


try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")

# Expected behaviour: The screen has changed from a main menu with several action buttons related to calendar options to a detailed calendar view displaying months and navigation controls.


try:
    driver.find_element(AppiumBy.XPATH, "//android.view.View[@resource-id='com.simplemobiletools.calendar.pro:id/small_month_view']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.calendar.pro:id/small_month_view': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.calendar.pro:id/small_month_view': FAILED")

# Expected behaviour: Tapping the button with resource_id "com.simplemobiletools.calendar.pro:id/small_month_view" expanded the view to display a calendar for January, including navigation buttons for changing months and multiple buttons representing days within the month.


try:
    driver.find_element(AppiumBy.XPATH, "//android.view.View[@resource-id='com.simplemobiletools.calendar.pro:id/month_view_background']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.calendar.pro:id/month_view_background': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.calendar.pro:id/month_view_background': FAILED")

# Expected behaviour: Tapping the button with the resource_id "com.simplemobiletools.calendar.pro:id/month_view_background" has navigated to a detailed view for a specific date, adding navigation arrows, a date display button for "December 31 2023 (Sun)", and another button to the screen.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@resource-id='com.simplemobiletools.calendar.pro:id/top_right_arrow']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.calendar.pro:id/top_right_arrow': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.calendar.pro:id/top_right_arrow': FAILED")

# Expected behaviour: The date displayed on the screen has changed from "December 31 2023 (Sun)" to "January 1 (Mon)" indicating a navigation to the next day, while the other buttons and their properties remain consistent.


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
