
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Create a new event, the task is 'laundry', save it
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")

# Expected behaviour: Touching the button with content description "New Event" has navigated the user from the main calendar screen to a new event creation screen, where various input fields and options for setting event details such as title, location, time, and reminders are now available. (page changed from Main to Event)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Title' and @resource-id='com.simplemobiletools.calendar.pro:id/event_title']").send_keys("laundry")
    print("Fill a focused textfield that has text 'Title' with 'laundry': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Title' with 'laundry': FAILED")

# Expected behaviour: The textfield that previously had the placeholder text "Title" is now filled with the text "laundry".


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Save' and @resource-id='com.simplemobiletools.calendar.pro:id/save']").click()
    print("Touch on a button that has content_desc 'Save': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Save': FAILED")

# Expected behaviour: After touching the button with content description "Save," the screen transitioned from the event creation interface to the main calendar view, and a temporary popup message "Saving�" was displayed. (page changed from Event to Main)


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
