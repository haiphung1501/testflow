
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.filemanager.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.filemanager.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.filemanager.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.filemanager.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.filemanager.pro',
        'com.simplemobiletools.filemanager.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Add 'alarms' as favorite
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Settings' and @resource-id='com.simplemobiletools.filemanager.pro:id/settings']").click()
    print("Touch on a button that has content_desc 'Settings': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Settings': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/settings_manage_favorites_holder']").click()
    print("Touch on a button that has text 'Manage favorites': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Manage favorites': FAILED")

# Expected behaviour: Touching the button with the text "Manage favorites" navigated from the Settings screen to the Favorites screen, which now includes a "Back" button, an "Add favorites" button, and a text explaining how to add favorites. (page changed from Settings to Favorites)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Add favorites' and @resource-id='com.simplemobiletools.filemanager.pro:id/add_favorite']").click()
    print("Touch on a button that has content_desc 'Add favorites': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Add favorites': FAILED")

# Expected behaviour: The action of touching the button with content description "Add favorites" resulted in the display of a new screen where the user can select a folder to add to their favorites. This new screen lists various folders such as "Alarms," "Android," "Audiobooks," etc., along with options to cancel or confirm the selection.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/list_item_holder']").click()
    print("Touch on a button that has text 'Alarms, 0 items': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Alarms, 0 items': FAILED")

# Expected behaviour: Tapping on the button that has text "Alarms, 0 items" navigated to a screen displaying the folder "/storage/emulated/0/Alarms," with options to manage favorites and an additional button to add favorites.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@resource-id='com.simplemobiletools.filemanager.pro:id/overflow_menu_icon']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.filemanager.pro:id/overflow_menu_icon': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.filemanager.pro:id/overflow_menu_icon': FAILED")

# Expected behaviour: Touching the button with resource_id "com.simplemobiletools.filemanager.pro:id/overflow_menu_icon" resulted in the appearance of a button with the text "Remove."


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
