
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.filemanager.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.filemanager.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.filemanager.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.filemanager.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.filemanager.pro',
        'com.simplemobiletools.filemanager.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Open 'android' folder, sort the files by extension
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Storage']").click()
    print("Touch on a button that has text 'Storage': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Storage': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/free_space_holder']").click()
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': FAILED")

# Expected behaviour: Touching the button "Internal, 5.3 GB, free[...and more]" opened a storage settings page, displaying detailed information about device and portable storage, including used and total storage capacities.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Internal shared storage, 2.66 GB used of 8.00 GB': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal shared storage, 2.66 GB used of 8.00 GB': FAILED")

# Expected behaviour: The action of touching the button for "Internal shared storage, 2.66 GB used of 8.00 GB" led to a detailed view of the internal storage usage, including a breakdown of storage categories like Photos & videos, Music & audio, Games, Movie & TV apps, Other apps, and Files. Additionally, options to manage storage and access the storage manager are now available.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Files, 0.00 GB': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Files, 0.00 GB': FAILED")
try:
    driver.back()
    print("Open the app again because you stayed on the pages not belonging to the target app for too long: SUCCESS")
    wait()
except Exception as e:
    print("Open the app again because you stayed on the pages not belonging to the target app for too long: FAILED")

# Expected behaviour: Touching the button with the text "Files, 0.00 GB" navigated from the SubSettings screen, which displayed detailed storage information and management options, to the Main screen, which shows an overview of internal and SD card storage with different storage sections and their capacities.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/free_space_holder']").click()
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': FAILED")

# Expected behaviour: The screen has changed from the main file manager view to the storage settings view, showing detailed information about the internal and portable storage usage.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='Back']").click()
    print("Touch on a button that has content_desc 'Back': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Back': FAILED")

# Expected behaviour: Touching the button with content description "Back" navigated from the "Settings$StorageDashboard" screen to the "Main" screen, changing the visible widgets and their properties accordingly.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/free_space_holder']").click()
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': FAILED")

# Expected behaviour: The user navigated from the main screen to the storage settings screen, which now displays detailed information about device and portable storage usage.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='Back']").click()
    print("Touch on a button that has content_desc 'Back': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Back': FAILED")

# Expected behaviour: The action of touching the "Back" button navigated the user from the "Settings$StorageDashboard" screen to the "Main" screen, changing the view from detailed storage information to a main menu with search and settings options.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/free_space_holder']").click()
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': FAILED")

# Expected behaviour: The action of touching the button with text "Internal, 5.3 GB, free" navigated the user to a screen displaying detailed storage information, including device storage and portable storage usage.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Internal shared storage, 2.69 GB used of 8.00 GB': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal shared storage, 2.69 GB used of 8.00 GB': FAILED")

# Expected behaviour: The screen has transitioned from a general storage overview to a detailed internal storage management page, displaying detailed usage information for various categories such as photos, music, and apps, along with options to manage storage.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Files, 0.00 GB': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Files, 0.00 GB': FAILED")
try:
    driver.back()
    print("Open the app again because you stayed on the pages not belonging to the target app for too long: SUCCESS")
    wait()
except Exception as e:
    print("Open the app again because you stayed on the pages not belonging to the target app for too long: FAILED")

# Expected behaviour: The user navigated from the SubSettings screen, showing detailed storage categories and usage, to the Main screen, displaying an overview of internal and SD card storage with options to manage files and view recent items.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.filemanager.pro:id/free_space_holder']").click()
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal, 5.3 GB, free[...and more]': FAILED")

# Expected behaviour: The screen transitioned from the main page to the storage settings page. The new screen displays detailed information about device storage, including internal shared storage and SD card usage, along with options to manage these storage types.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.LinearLayout[]").click()
    print("Touch on a button that has text 'Internal shared storage, 2.72 GB used of 8.00 GB': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Internal shared storage, 2.72 GB used of 8.00 GB': FAILED")

# Expected behaviour: The user navigated from the general storage overview screen to a detailed internal storage management screen, which now displays specific categories of storage usage such as "Photos & videos," "Music & audio," "Games," and more, along with their respective storage usage amounts.


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
