
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Delete all the events in the Calendar app
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='More options']").click()
    print("Touch on a button that has content_desc 'More options': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'More options': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Settings']").click()
    print("Touch on a button that has text 'Settings': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Settings': FAILED")

# Expected behaviour: Touching the button with the text "Settings" navigated the user from the Main screen to the Settings screen, which now displays various customization and general settings options, including buttons and checkboxes for managing event types, customizing colors, and setting reminders. (page changed from Main to Settings)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.calendar.pro:id/settings_manage_event_types_holder']").click()
    print("Touch on a button that has text 'Manage event types': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Manage event types': FAILED")

# Expected behaviour: The screen has changed from the "Settings" page to the "Manage Event Types" page, which now includes options to add a new event type and manage existing event types such as "Holidays" and "Regular event." (page changed from Settings to ManageEventTypes)


try:
    elem = driver.find_element(AppiumBy.XPATH, "//android.widget.FrameLayout[@resource-id='com.simplemobiletools.calendar.pro:id/event_item_frame']")
    action = TouchAction(driver)
    action.long_press(elem).perform()
    print("Long touch on a button that has text 'Holidays': SUCCESS")
    wait()
except Exception as e:
    print("Long touch on a button that has text 'Holidays': FAILED")

# Expected behaviour: The "Holidays" textview and associated buttons have been selected, and additional buttons with the content descriptions "Done," "Edit," and "Delete," as well as a button with the text "1 / 2," have appeared.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Delete' and @resource-id='com.simplemobiletools.calendar.pro:id/cab_delete']").click()
    print("Touch on a button that has content_desc 'Delete': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Delete': FAILED")

# Expected behaviour: The action of touching the "Delete" button has brought up options related to handling affected events, specifically providing the choices to either "Move affected events into the default event type" or "Permanently remove affected events."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RadioButton[@text='Permanently remove affected events']").click()
    print("Touch on a button that has text 'Permanently remove affected events': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Permanently remove affected events': FAILED")

# Expected behaviour: The screen transitioned from providing options to manage affected events to displaying the main interface for managing event types, including buttons for navigation, adding new types, and viewing regular events.


try:
    elem = driver.find_element(AppiumBy.XPATH, "//android.widget.FrameLayout[@resource-id='com.simplemobiletools.calendar.pro:id/event_item_frame']")
    action = TouchAction(driver)
    action.long_press(elem).perform()
    print("Long touch on a button that has text 'Regular event': SUCCESS")
    wait()
except Exception as e:
    print("Long touch on a button that has text 'Regular event': FAILED")

# Expected behaviour: The "Regular event" text and related buttons are now selected, and additional buttons labeled "Done," "1 / 1," "Edit," and "Delete" have appeared.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Delete' and @resource-id='com.simplemobiletools.calendar.pro:id/cab_delete']").click()
    print("Touch on a button that has content_desc 'Delete': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Delete': FAILED")

# Expected behaviour: A confirmation dialog for deletion has appeared, asking "Are you sure you want to proceed with the deletion?" with options "No" and "Yes".


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='Yes' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'Yes': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Yes': FAILED")

# Expected behaviour: The confirmation prompt for deletion has disappeared, and a message indicating that the default event type cannot be deleted was briefly shown. The screen now shows the main "Manage event types" interface with options to navigate back, add a new type, and manage existing event types.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='Back']").click()
    print("Touch on a button that has content_desc 'Back': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Back': FAILED")

# Expected behaviour: By touching the button with content description "Back", the screen has navigated from the "ManageEventTypes" page to the "Settings" page. The new screen displays various settings options such as "COLOR CUSTOMIZATION", "GENERAL", and "REMINDERS". (page changed from ManageEventTypes to Settings)


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
