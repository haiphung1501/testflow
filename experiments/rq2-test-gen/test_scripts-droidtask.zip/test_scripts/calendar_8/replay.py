
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Add the event of 'VisitParents' on july 30, remind me 1 hour before, save
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='New Event' and @resource-id='com.simplemobiletools.calendar.pro:id/calendar_fab']").click()
    print("Touch on a button that has content_desc 'New Event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'New Event': FAILED")

# Expected behaviour: The action of touching the button with content description "New Event" resulted in navigating from the main screen to the event creation screen, where you can now enter details for a new event, such as title, location, description, and other event-specific information. (page changed from Main to Event)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Title' and @resource-id='com.simplemobiletools.calendar.pro:id/event_title']").send_keys("VisitParents")
    print("Fill a focused textfield that has text 'Title' with 'VisitParents': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Title' with 'VisitParents': FAILED")

# Expected behaviour: The textfield that previously had the text "Title" is now filled with the text "VisitParents".


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='September 10 (Tue)' and @resource-id='com.simplemobiletools.calendar.pro:id/event_start_date']").click()
    print("Touch on a button that has text 'September 10 (Tue)': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'September 10 (Tue)': FAILED")

# Expected behaviour: Touching the button with the text "September 10 (Tue)" opened a date picker dialog, displaying a calendar for the year 2024 with selectable dates and navigation buttons to switch between months.


try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_x -= width * 2 / 5
    end_x += width * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll left on a scrollable area that has text '1, 2, 3[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll left on a scrollable area that has text '1, 2, 3[...and more]': FAILED")

# Expected behaviour: Scrolling left on the scrollable area revealed buttons with text "7," "8," "9," and "31" and changed the button with text "10" from a checked, selected state to a normal state.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@content-desc='Previous month' and @resource-id='android:id/prev']").click()
    print("Touch on a button that has content_desc 'Previous month': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Previous month': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_x -= width * 2 / 5
    end_x += width * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll left on a scrollable area that has text '1, 2, 3[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll left on a scrollable area that has text '1, 2, 3[...and more]': FAILED")

# Expected behaviour: The scrollable area has moved left, causing the button with the text "31" to disappear and buttons with the texts "28", "29", and "30" to appear.


try:
    driver.find_element(AppiumBy.XPATH, "//android.view.View[@text='30' and @content-desc='30 June 2024']").click()
    print("Touch on a button that has text '30': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text '30': FAILED")

# Expected behaviour: The button with the text "30" has changed to a checked, selected state, and the button with the text "Tue, Sep 10" has been replaced with a button that has the text "Sun, Jun 30."


try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text '1, 2, 3[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text '1, 2, 3[...and more]': FAILED")
try:
    deviceSize = driver.get_window_size()
    width = deviceSize['width']
    height = deviceSize['height']
    start_x, start_y = width/2, height/2
    end_x, end_y = width/2, height/2
    duration = 500
    start_y += height * 2 / 5
    end_y -= height * 2 / 5
    driver.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration=duration)
    print("Scroll down on a scrollable area that has text '1, 2, 3[...and more]': SUCCESS")
    wait()
except Exception as e:
    print("Scroll down on a scrollable area that has text '1, 2, 3[...and more]': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")

# Expected behaviour: Touching the "OK" button transitioned the screen from a date selection interface to an event creation interface, displaying fields for event details such as title, location, description, and time, along with options to save the event.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='10 minutes before' and @resource-id='com.simplemobiletools.calendar.pro:id/event_reminder_1']").click()
    print("Touch on a button that has text '10 minutes before': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text '10 minutes before': FAILED")

# Expected behaviour: The screen now displays a list of reminder options, and the button with the text "10 minutes before" is now checked.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RadioButton[@text='1 hour before']").click()
    print("Touch on a button that has text '1 hour before': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text '1 hour before': FAILED")

# Expected behaviour: The screen transitioned from a list of reminder options to the event creation screen, where details about the new event, such as title, location, and time, can be entered and saved.


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
