
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.smsmessenger" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.smsmessenger" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.smsmessenger":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.smsmessenger is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.smsmessenger',
        'com.simplemobiletools.smsmessenger.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Send long messages as MMS
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageButton[@resource-id='com.simplemobiletools.smsmessenger:id/conversations_fab']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.smsmessenger:id/conversations_fab': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.smsmessenger:id/conversations_fab': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Add Contact or Number�' and @resource-id='com.simplemobiletools.smsmessenger:id/new_conversation_address']").send_keys("1234567890")
    print("Fill a focused textfield that has text 'Add Contact or Number' with '1234567890': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Add Contact or Number' with '1234567890': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@resource-id='com.simplemobiletools.smsmessenger:id/new_conversation_confirm']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.smsmessenger:id/new_conversation_confirm': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.smsmessenger:id/new_conversation_confirm': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Type a message�' and @resource-id='com.simplemobiletools.smsmessenger:id/thread_type_message']").send_keys("Hi there! This is a test message to check how the MMS functionality works in the SMS Messenger app. I hope this long message is sent successfully as an MMS. Have a great day!")
    print("Fill a textfield that has text 'Type a message' with 'Hi there! This is a test message to check how the MMS functionality works in the SMS Messenger app. I hope this long message is sent successfully as an MMS. Have a great day!': SUCCESS")
    wait()
except Exception as e:
    print("Fill a textfield that has text 'Type a message' with 'Hi there! This is a test message to check how the MMS functionality works in the SMS Messenger app. I hope this long message is sent successfully as an MMS. Have a great day!': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='SMS' and @content-desc='OK' and @resource-id='com.simplemobiletools.smsmessenger:id/thread_send_message']").click()
    print("Touch on a button that has text 'SMS': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'SMS': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@content-desc='Attachment' and @resource-id='com.simplemobiletools.smsmessenger:id/thread_add_attachment']").click()
    print("Touch on a button that has content_desc 'Attachment': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Attachment': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Choose photo' and @resource-id='com.simplemobiletools.smsmessenger:id/choose_photo']").click()
    print("Touch on a button that has text 'Choose photo': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Choose photo': FAILED")
try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Choose photo' and @resource-id='com.simplemobiletools.smsmessenger:id/choose_photo']").click()
    print("Touch on a button that has text 'Choose photo': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Choose photo': FAILED")
try:
    driver.back()
    print("Press 'BACK' button to navigate back: SUCCESS")
    wait()
except Exception as e:
    print("Press 'BACK' button to navigate back: FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Choose photo' and @resource-id='com.simplemobiletools.smsmessenger:id/choose_photo']").click()
    print("Touch on a button that has text 'Choose photo': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Choose photo': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//com.google.android.material.chip.Chip[@text='Large files']").click()
    print("Touch on a button that has text 'Large files': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Large files': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@content-desc='List view' and @resource-id='com.android.documentsui:id/sub_menu_list']").click()
    print("Touch on a button that has content_desc 'List view': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'List view': FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
