
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.musicplayer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.musicplayer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.musicplayer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.musicplayer',
        'com.simplemobiletools.musicplayer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Change the event type 'regular event' to 'deadlines'
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Settings' and @resource-id='com.simplemobiletools.calendar.pro:id/settings']").click()
    print("Touch on a button that has content_desc 'Settings': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Settings': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RelativeLayout[@resource-id='com.simplemobiletools.calendar.pro:id/settings_manage_event_types_holder']").click()
    print("Touch on a button that has text 'Manage event types': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Manage event types': FAILED")

# Expected behaviour: The screen has changed from the "Settings" page to the "Manage Event Types" page, displaying a button with content description "Add a new type" and a textview with the text "Regular event." (page changed from Settings to ManageEventTypes)


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.FrameLayout[@resource-id='com.simplemobiletools.calendar.pro:id/event_item_frame']").click()
    print("Touch on a button that has text 'Regular event': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Regular event': FAILED")

# Expected behaviour: Tapping the "Regular event" button opened an editing screen for the event type. This new screen allows the user to edit the event name, change the event color, and either cancel or confirm the changes.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Regular event' and @resource-id='com.simplemobiletools.calendar.pro:id/type_title']").send_keys("deadlines")
    print("Fill a focused textfield that has text 'Regular event' with 'deadlines': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Regular event' with 'deadlines': FAILED")

# Expected behaviour: The textfield that previously contained the text "Regular event" now contains the text "deadlines".


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")

# Expected behaviour: The screen has transitioned from an editing interface back to the main management interface for event types. The "Edit type" interface with textfields and buttons for "Cancel" and "OK" is replaced by the "Manage event types" interface, which includes buttons for navigating back, adding a new type, and accessing the overflow menu.


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
