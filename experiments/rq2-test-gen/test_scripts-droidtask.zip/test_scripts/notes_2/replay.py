
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.notes.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.notes.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.notes.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.notes.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.notes.pro',
        'com.simplemobiletools.notes.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Create a checklist note called 'NewCheckList'
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Create a new note' and @resource-id='com.simplemobiletools.notes.pro:id/new_note']").click()
    print("Touch on a button that has content_desc 'Create a new note': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Create a new note': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Label' and @resource-id='com.simplemobiletools.notes.pro:id/locked_note_title']").send_keys("NewCheckList")
    print("Fill a focused textfield that has text 'Label' with 'NewCheckList': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Label' with 'NewCheckList': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RadioButton[@text='Checklist' and @resource-id='com.simplemobiletools.notes.pro:id/type_checklist']").click()
    print("Touch on a button that has text 'Checklist': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Checklist': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
