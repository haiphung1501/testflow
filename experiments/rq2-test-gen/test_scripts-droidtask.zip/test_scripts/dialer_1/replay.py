
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=5):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.dialer" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.dialer" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.dialer":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.dialer is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.dialer',
        'com.simplemobiletools.dialer.activities.MainActivity')
device.connect()
driver = device.driver
wait()

"""
1. Create a new contact Alice, mobile number 31232134
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Create new contact' and @resource-id='com.simplemobiletools.dialer:id/create_new_contact']").click()
    print("Touch on a button that has content_desc 'Create new contact': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Create new contact': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='First name' and @resource-id='com.simplemobiletools.contacts.pro:id/contact_first_name']").send_keys("Alice")
    print("Fill a textfield that has text 'First name' with 'Alice': SUCCESS")
    wait()
except Exception as e:
    print("Fill a textfield that has text 'First name' with 'Alice': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Number' and @resource-id='com.simplemobiletools.contacts.pro:id/contact_number']").send_keys("31232134")
    print("Fill a textfield that has text 'Number' with '31232134': SUCCESS")
    wait()
except Exception as e:
    print("Fill a textfield that has text 'Number' with '31232134': FAILED")
try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Save' and @resource-id='com.simplemobiletools.contacts.pro:id/save']").click()
    print("Touch on a button that has content_desc 'Save': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Save': FAILED")
screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
