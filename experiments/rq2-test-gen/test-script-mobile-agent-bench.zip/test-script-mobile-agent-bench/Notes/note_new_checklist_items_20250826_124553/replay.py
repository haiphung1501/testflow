
import sys
import time
import uiautomator2 as u2
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from device import Device
from config import *

def wait(seconds=3):
    for i in range(0, seconds):
        print("wait 1 second ..")
        time.sleep(1)

def wait_until_activity(d, activity_name, max_wait=30):
    for i in range(0, max_wait):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.notes.pro" and activity_name in current_app['activity']:
            break
        time.sleep(1)
    
    # if the target activity is not launched, raise exception
    current_app = d.app_current()
    if current_app['package'] != "com.simplemobiletools.notes.pro" or activity_name not in current_app['activity']:
        raise Exception(f"Action precondition cannot be satisfied: %s is not launched" % activity_name)

def go_back_until_inside_app(d, max_backtrack=10):
    for i in range(0, max_backtrack):
        current_app = d.app_current()
        if current_app['package'] == "com.simplemobiletools.notes.pro":
            break
        d.press("back")
    
    raise Exception(f"Backtrack failed: com.simplemobiletools.notes.pro is not launched")

def setup_device(platform, platformVersion, deviceName, appPackage, appActivity):
        device = Device(
            platform=platform,
            platformVersion=platformVersion,
            deviceName=deviceName,
            appPackage=appPackage,
            appActivity=appActivity,
        )
        return device

config = AppConfig()
config.load_from_env()
device = setup_device(
        config.platform,
        config.platformVersion,
        config.deviceName,
        'com.simplemobiletools.notes.pro',
        'com.simplemobiletools.notes.pro.activities.MainActivity')
device.connect()
driver = device.driver
wait()


try:
    # Try to run mobile-agent-bench setup() before replay
    import os
    import sys
    import time
    
    # Add mobile-agent-bench src to sys.path
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    mab_src = os.path.join(repo_root, 'mobile-agent-bench', 'src')
    
    if os.path.isdir(mab_src) and mab_src not in sys.path:
        sys.path.insert(0, mab_src)
    
    try:
        from mobile_agent_benchmark.bench_task import Task as _BenchTask
        import importlib
        
        # Map task names to module names (handle special cases)
        task_to_module = {
            'calendar_delete_tasks': 'calendar_delete_tasks',
            'contacts_create': 'contacts_create',
            'contacts_delete': 'contacts_delete',
            'contacts_favorite': 'contacts_favorite',
            'contacts_filter': 'contacts_filter',
            'contacts_hide_email': 'contacts_hide_email',
            'contacts_modify': 'contacts_modify',
            'contacts_remove_dialog': 'contacts_remove_dialog',
            'contacts_search': 'contacts_search',
            'contacts_sort': 'contacts_sort',
            'contacts_about': 'contacts_about',
            'gallery_filter_by_images_and_videos': 'gallery_filter_by_images_and_videos',
            'gallery_group_by_file_type': 'gallery_group_by_file_type',
            'gallery_list_view_type': 'gallery_list_view_type',
            'gallery_play_videos_automatically': 'gallery_play_videos_automatically',
            'gallery_remember_playback_position': 'gallery_remember_playback_position',
            'gallery_set_favorite': 'gallery_set_favorite',
            'gallery_set_wallpaper': 'gallery_set_wallpaper',
            'gallery_show_hidden_items': 'gallery_show_hidden_items',
            'gallery_sort_by_size_asc': 'gallery_sort_by_size_asc',
            'gallery_use_24_hour_time_format': 'gallery_use_24_hour_time_format',
            'filemanager_check_file_properties': 'filemanager_check_file_properties',
            'filemanager_check_storage': 'filemanager_check_storage',
            'filemanager_create_new_file': 'filemanager_create_new_file',
            'filemanager_delete_file': 'filemanager_delete_file',
            'filemanager_delete_txt': 'filemanager_delete_txt',
            'filemanager_delete_videos': 'filemanager_delete_videos',
            'filemanager_hide_folder': 'filemanager_hide_folder',
            'filemanager_rename_file': 'filemanager_rename_file',
            'filemanager_search_file': 'filemanager_search_file',
            'filemanager_sort_folder_by_size_desc': 'filemanager_sort_folder_by_size_desc',
            'calendar_create_and_search': 'calendar_create_and_search',
            'calendar_daily_view': 'calendar_daily_view',
            'calendar_laundry': 'calendar_laundry',
            'calendar_new_task': 'calendar_new_task',
            'calendar_next_month': 'calendar_next_month',
            'calendar_open_about': 'calendar_open_about',
            'calendar_search': 'calendar_search',
            'calendar_snooze_time': 'calendar_snooze_time',
            'calendar_start_week': 'calendar_start_week',
            'launcher_add_apps': 'launcher_add_apps',
            'launcher_check_contributor': 'launcher_check_contributor',
            'launcher_hide_app_name': 'launcher_hide_app_name',
            'launcher_open_about_FAQ': 'launcher_open_about_FAQ',
            'launcher_remove_app': 'launcher_remove_app',
            'launcher_rename_app': 'launcher_rename_app',
            'launcher_search_app': 'launcher_search_app',
            'launcher_setting_close_app_when_launching': 'launcher_setting_close_app_when_launching',
            'launcher_sort_by_custom': 'launcher_sort_by_custom',
            'launcher_sort_by_title_desc': 'launcher_sort_by_title_desc',
            'messager_add_block_numbers': 'messager_add_block_numbers',
            'messager_change_font_size': 'messager_change_font_size',
            'messager_check_message_properties': 'messager_check_message_properties',
            'messager_create_conversation_and_check_message_properties': 'messager_create_conversation_and_check_message_properties',
            'messager_create_conversation_and_search': 'messager_create_conversation_and_search',
            'messager_make_conversation_archived': 'messager_make_conversation_archived',
            'messager_search_contacts': 'messager_search_contacts',
            'messager_search_message': 'messager_search_message',
            'messager_show_archived_messages': 'messager_show_archived_messages',
            'messager_start_a_conversation': 'messager_start_a_conversation',
            'music_player_album_sort_by_year': 'music_player_album_sort_by_year',
            'music_player_config_equalizer': 'music_player_config_equalizer',
            'music_player_create_playlist': 'music_player_create_playlist',
            'music_player_create_playlist_and_search': 'music_player_create_playlist_and_search',
            'music_player_create_playlist_and_sort_desc': 'music_player_create_playlist_and_sort_desc',
            'music_player_open_faq': 'music_player_open_faq',
            'music_player_open_settings': 'music_player_open_settings',
            'music_player_playlist_sort_desc': 'music_player_playlist_sort_desc',
            'music_player_rescan_media': 'music_player_rescan_media',
            'music_player_search_playlist': 'music_player_search_playlist',
            'note_add': 'note_add',
            'note_delete': 'note_delete',
            'note_item_checked': 'note_item_checked',
            'note_lock': 'note_lock',
            'note_new_checklist': 'note_new_checklist',
            'note_new_checklist_items': 'note_new_checklist_items',
            'note_open': 'note_open',
            'note_open_about': 'note_open_about',
            'note_rename': 'note_rename',
            'note_search': 'note_search',
            'recorder_bit_rate': 'recorder_bit_rate',
            'recorder_delete': 'recorder_delete',
            'recorder_delete_all': 'recorder_delete_all',
            'recorder_empty_trash': 'recorder_empty_trash',
            'recorder_extension': 'recorder_extension',
            'recorder_recycle_bin': 'recorder_recycle_bin',
            'recorder_recycle_settings': 'recorder_recycle_settings',
            'recorder_rename': 'recorder_rename',
            'recorder_rename_all': 'recorder_rename_all',
            'recorder_theme': 'recorder_theme',
            'calculator_add': 'calculator_add',
            'calculator_convert_length': 'calculator_convert_length',
            'calculator_cube': 'calculator_cube',
            'calculator_divide': 'calculator_divide',
            'calculator_minus': 'calculator_minus',
            'calculator_mixed': 'calculator_mixed',
            'calculator_multiply': 'calculator_multiply',
            'calculator_point': 'calculator_point',
            'calculator_recalculate': 'calculator_recalculate',
            'calculator_square': 'calculator_square'
        }
        
        module_name = task_to_module.get('note_new_checklist_items', 'note_new_checklist_items')
        try:
            mod = importlib.import_module(f"mobile_agent_benchmark.tasks.{module_name}")
            
            # Discover the Task subclass in the module
            bench_task_cls = None
            for attr_name in dir(mod):
                attr = getattr(mod, attr_name)
                try:
                    if isinstance(attr, type) and issubclass(attr, _BenchTask) and attr is not _BenchTask:
                        bench_task_cls = attr
                        break
                except Exception:
                    pass
            
            if bench_task_cls is not None:
                print(f'Found Task class {bench_task_cls.__name__} for note_new_checklist_items')
                
                # Try to connect AndroidViewClient with better error handling
                try:
                    from com.dtmilano.android.viewclient import ViewClient
                    serial = os.environ.get('APP_ANDROID_SERIAL', 'emulator-5554')
                    print(f'Connecting to device {serial} for setup...')
                    
                    # Wait a bit for device to be ready
                    time.sleep(2)
                    
                    device_vc, serialno = ViewClient.connectToDeviceOrExit(serialno=serial)
                    vc = ViewClient(device_vc, serialno)
                    
                    # Try to dump with timeout
                    vc.dump()
                    print('ViewClient connected successfully')
                    
                    # Create task instance and run setup
                    bench_task = bench_task_cls()
                    bench_task.setup(vc)
                    print('Setup() from mobile-agent-bench executed successfully')
                    
                except Exception as vc_error:
                    print(f'ViewClient setup failed: {vc_error}')
                    print('Continuing without setup() - task may not have proper preconditions')
                    
            else:
                print(f'No Task subclass found for note_new_checklist_items; skipping setup')
                
        except ImportError as imp_err:
            print(f'Could not import task module {module_name}: {imp_err}')
            print('Continuing without setup() - task may not have proper preconditions')
            
    except Exception as bench_err:
        print(f'Benchmark setup failed: {bench_err}')
        print('Continuing without setup() - task may not have proper preconditions')

except Exception as _setup_err:
    print('Setup() step failed with unexpected error:', _setup_err)
    print('Continuing without setup() - task may not have proper preconditions')

"""
1. Create a checklist named 'Shopping list' and add an item named 'Milk'
"""

try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Create a new note' and @resource-id='com.simplemobiletools.notes.pro:id/new_note']").click()
    print("Touch on a button that has content_desc 'Create a new note': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has content_desc 'Create a new note': FAILED")

# Expected behaviour: The action of touching the button with content description "Create a new note" resulted in the transition to a new screen where the user is prompted to add a new note, with options to input a label, choose the note type, and either confirm or cancel the creation of the note.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@text='Label' and @resource-id='com.simplemobiletools.notes.pro:id/locked_note_title']").send_keys("Shopping list")
    print("Fill a focused textfield that has text 'Label' with 'Shopping list': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has text 'Label' with 'Shopping list': FAILED")

# Expected behaviour: The textfield that previously displayed the text "Label" has been filled with the text "Shopping list."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.RadioButton[@text='Checklist' and @resource-id='com.simplemobiletools.notes.pro:id/type_checklist']").click()
    print("Touch on a button that has text 'Checklist': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Checklist': FAILED")

# Expected behaviour: The "Checklist" button was previously unchecked and is now checked, while the "Text note" button was previously checked and is now unchecked.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='OK' and @resource-id='android:id/button1']").click()
    print("Touch on a button that has text 'OK': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'OK': FAILED")

# Expected behaviour: The action of touching the "OK" button has transitioned the screen from a note creation interface to a note viewing interface. The screen now displays options for interacting with the note, including buttons for "Open note," "Create a new note," and "More options," along with a view of the "Shopping list" note and an option to "Add new checklist items."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Add new checklist items' and @resource-id='com.simplemobiletools.notes.pro:id/fragment_placeholder_2']").click()
    print("Touch on a button that has text 'Add new checklist items': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has text 'Add new checklist items': FAILED")

# Expected behaviour: The action of touching the "Add new checklist items" button resulted in opening a new interface for adding checklist items, which includes a focused textfield to enter the new item, and buttons labeled "Cancel" and "OK" for confirming or canceling the addition.


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='com.simplemobiletools.notes.pro:id/title_edit_text']").send_keys("Milk")
    print("Fill a focused textfield that has resource_id 'com.simplemobiletools.notes.pro:id/title_edit_text' with 'Milk': SUCCESS")
    wait()
except Exception as e:
    print("Fill a focused textfield that has resource_id 'com.simplemobiletools.notes.pro:id/title_edit_text' with 'Milk': FAILED")

# Expected behaviour: The textfield with the resource_id "com.simplemobiletools.notes.pro:id/title_edit_text," which was previously focused and empty, is now filled with the text "Milk."


try:
    driver.find_element(AppiumBy.XPATH, "//android.widget.ImageView[@resource-id='com.simplemobiletools.notes.pro:id/add_item']").click()
    print("Touch on a button that has resource_id 'com.simplemobiletools.notes.pro:id/add_item': SUCCESS")
    wait()
except Exception as e:
    print("Touch on a button that has resource_id 'com.simplemobiletools.notes.pro:id/add_item': FAILED")

# Expected behaviour: Touching the "add_item" button added a new focused textfield with resource_id "com.simplemobiletools.notes.pro:id/title_edit_text", allowing the user to input a new checklist item.


screenshot_path = "./script_state.png"
driver.get_screenshot_as_file(screenshot_path)
